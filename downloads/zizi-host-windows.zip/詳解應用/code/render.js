// 可重用的產檔模組（供本機網頁應用 local-app 與未來 qbank 整合使用）。
// 網頁與 build_from_json.js CLI 共用此 renderer。
const { Document, Packer, Paragraph, TextRun } = require("docx");
const {
  buildQuestionsTable, run, sectionTitle, FONT, FONT_SIZE, LINE_SPACING, LINE_RULE, PAGE_MARGIN,
} = require("./lib3");

// docx-js has no paragraph API for these Word settings; normalize every paragraph.
async function normalizeParagraphs(buffer) {
  const zip=await require('jszip').loadAsync(buffer);
  for(const name of ['word/document.xml','word/styles.xml']) {
  let xml=await zip.file(name).async('string');
  const settings='<w:snapToGrid w:val="0"/><w:adjustRightInd w:val="0"/><w:contextualSpacing w:val="0"/>';
  xml=xml.replace(/<w:pPr\b[^>]*\/>/g,'<w:pPr>'+settings+'</w:pPr>').replace(/<w:pPr>([\s\S]*?)<\/w:pPr>/g,(_,body)=>'<w:pPr>'+body.replace(/<w:(?:snapToGrid|adjustRightInd|contextualSpacing)\b[^>]*\/>/g,'')+settings+'</w:pPr>');
  xml=xml.replace(/<w:p>(?!<w:pPr>)/g,'<w:p><w:pPr>'+settings+'<w:spacing w:before="0" w:after="0" w:line="240" w:lineRule="auto"/></w:pPr>');
  zip.file(name,xml);
 }
 return zip.generateAsync({type:'nodebuffer'});
}
// 極簡 CSV 解析（支援雙引號欄位內的換行、逗號、"" 轉義）——不外加相依套件。
function parseCsv(text) {
  const rows = []; let row = [], field = "", q = false;
  text = String(text).replace(/^﻿/, "").replace(/\r\n?/g, "\n");
  for (let i = 0; i < text.length; i++) {
    const c = text[i];
    if (q) {
      if (c === '"') { if (text[i + 1] === '"') { field += '"'; i++; } else q = false; }
      else field += c;
    } else if (c === '"') q = true;
    else if (c === ",") { row.push(field); field = ""; }
    else if (c === "\n") { row.push(field); rows.push(row); row = []; field = ""; }
    else field += c;
  }
  if (field.length || row.length) { row.push(field); rows.push(row); }
  return rows.filter((r) => r.some((c) => c.trim() !== ""));
}

// 由題庫 23 欄 CSV 直接生「乾淨考卷 Word」（docx-js，純 Node，不需 Python）。
// 題目欄的 $LaTeX$ 原樣保留供 MathType；〔含圖〕留為佔位。
async function buildCleanExamBuffer(csvText) {
  const rows = parseCsv(csvText);
  if (!rows.length) throw new Error("CSV 是空的");
  const head = rows[0].map((h) => h.trim());
  const idx = (n) => head.indexOf(n);
  const iNo = idx("題號"), iQ = idx("題目"), iPassage = idx("題組文章");
  const data = rows.slice(1).filter((r) => /^\d+$/.test((r[iNo] || "").trim()))
    .sort((a, b) => Number(a[iNo]) - Number(b[iNo]));
  const sp = { line: LINE_SPACING, lineRule: LINE_RULE };
  const children = [new Paragraph({
    spacing: { after: 160, ...sp },
    children: [run(`單選題【共 ${data.length} 題】`, { bold: true })],
  })];
  const lineRuns = (txt, firstPrefix) => String(txt).split("\n").map((ln, i) =>
    new TextRun({ text: (i === 0 ? (firstPrefix || "") + ln : ln), break: i === 0 ? 0 : 1, font: FONT, size: FONT_SIZE }));
  data.forEach((r) => {
    if (iPassage >= 0 && (r[iPassage] || "").trim()) {
      children.push(new Paragraph({ spacing: { before: 108, after: 36, ...sp }, indent: { left: 360 },
        children: lineRuns("◎ " + r[iPassage].trim()) }));
    }
    children.push(new Paragraph({ spacing: { before: 72, after: 72, ...sp },
      children: lineRuns(r[iQ] || "", (r[iNo] || "") + ". ") }));
  });
  const doc = new Document({ sections: [{
    properties: { page: { size: { width: 11906, height: 16838 },
      margin: { top: PAGE_MARGIN, bottom: PAGE_MARGIN, left: PAGE_MARGIN, right: PAGE_MARGIN, gutter: 0 } } },
    children }] });
  return normalizeParagraphs(await Packer.toBuffer(doc));
}

// 答案一致性自檢：正向題比對「正確」、否定題比對「錯誤」的選項集合。
// 回傳不一致的題號陣列（空陣列代表通過）。
const { isMismatch } = require('../local-app/public/answer-rules');
function checkAnswers(questions) {
  const items = Array.isArray(questions) ? questions : (Array.isArray(questions && questions.sections)
    ? questions.sections.flatMap((section) => section.questions || section.items || []) : (questions && questions.questions) || []);
  return items.filter(isMismatch).map((q) => q.no);
}

// 由題目答案組出簡答速查列（每 5 題一組，以 / 分隔）。
function buildSummaryLine(data) {
  const questions = Array.isArray(data.sections) && data.sections.length
    ? data.sections.flatMap((section) => section.questions || section.items || []) : (data.questions || []);
  const answerString = questions.map((q) => q.answer).join("");
  const groups = [];
  for (let i = 0; i < answerString.length; i += 5) groups.push(answerString.slice(i, i + 5));
  return data.answerKeyMode === true || normalizeHeading(data.unitName) ? groups.join("/") : `${data.summaryLabel || "需人工確認"} ${groups.join("/")}`;
}

function normalizeHeading(value) {
  return Array.from(typeof value === 'string' ? value.trim() : '').slice(0, 60).join('');
}

// data → docx Buffer。簡答速查列在最上方，接著逐題詳解表格（同一份文件）。
async function buildDocxBuffer(data) {
  const sections = Array.isArray(data.sections) && data.sections.length
    ? data.sections.map((section) => ({ title: String(section.title || ""), questions: section.questions || section.items || [] }))
    : [{ title: "", questions: data.questions || [] }];
  const children = [];
  const docTitle = normalizeHeading(data.docTitle), unitName = normalizeHeading(data.unitName);
  // Template: title 22pt in a text box (3.75pt outline), unit 14pt.
  // Use the requested single paragraph border; 3.6pt padding matches the box inset.
  if (docTitle) children.push(new Paragraph({
    alignment: 'center', keepNext: true,
    border: Object.fromEntries(['top', 'bottom', 'left', 'right'].map(side =>
      [side, { style: 'single', size: 30, color: '000000', space: 4 }])),
    spacing: { before: 0, after: 72, line: LINE_SPACING, lineRule: LINE_RULE },
    children: [new TextRun({ text: docTitle, bold: true, size: 44,
      font: { ascii: '華康細圓體', hAnsi: '華康細圓體', eastAsia: '華康細圓體', cs: 'Times New Roman' } })],
  }));
  if (unitName) children.push(new Paragraph({
    alignment: 'center', keepNext: true,
    spacing: { before: 0, after: 0, line: LINE_SPACING, lineRule: LINE_RULE },
    children: [new TextRun({ text: `【 ${unitName} 詳解 】`, bold: true, size: 28, font: FONT })],
  }));
  children.push(new Paragraph({
    alignment: "center",
    spacing: { before: 0, after: 180, line: LINE_SPACING, lineRule: LINE_RULE },
    children: [run(buildSummaryLine(data), { bold: true })],
  }));
  if (!sections.some((section) => section.title)) {
    const questions = sections.flatMap((section) => section.questions);
    if (questions.length) children.push(buildQuestionsTable(questions));
  } else {
    sections.forEach((section) => {
      if (section.title) children.push(sectionTitle(section.title));
      if (section.questions.length) children.push(buildQuestionsTable(section.questions));
    });
  }

  const doc = new Document({
    styles: { default: { document: { run: { font: FONT, size: FONT_SIZE } } } },
    sections: [{
      properties: {
        page: {
          size: { width: 11906, height: 16838 }, // A4
          margin: { top: PAGE_MARGIN, bottom: PAGE_MARGIN, left: PAGE_MARGIN, right: PAGE_MARGIN, gutter: 0 },
        },
      },
      children,
    }],
  });
  return normalizeParagraphs(await Packer.toBuffer(doc));
}

module.exports = { checkAnswers, buildSummaryLine, buildDocxBuffer, buildCleanExamBuffer, parseCsv };
