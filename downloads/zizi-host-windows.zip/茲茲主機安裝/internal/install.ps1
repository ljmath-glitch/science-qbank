﻿param(
    [string]$Source = (Join-Path $PSScriptRoot '詳解應用')
)
$ErrorActionPreference = 'Stop'
[Console]::OutputEncoding = New-Object Text.UTF8Encoding($false)
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

function Refresh-Path {
    $env:Path = [Environment]::GetEnvironmentVariable('Path', 'Machine') + ';' + [Environment]::GetEnvironmentVariable('Path', 'User')
    $env:Path += ';' + (Join-Path $env:LOCALAPPDATA 'Microsoft\WindowsApps')
    $env:Path += ';' + (Join-Path $env:LOCALAPPDATA 'Programs\Python\Launcher')
}

function Install-Package([string]$Id) {
    if (-not (Get-Command winget -ErrorAction SilentlyContinue)) {
        throw '找不到 winget。請先從 Microsoft Store 更新「應用程式安裝程式」，再重新執行。'
    }
    Write-Host "正在安裝 $Id，Windows 可能要求確認安裝…" -ForegroundColor Cyan
    & winget install --id $Id --exact --source winget --disable-interactivity
    if ($LASTEXITCODE -ne 0) { throw "$Id 安裝未完成，結束碼 $LASTEXITCODE。請查看上方訊息後重試。" }
    Refresh-Path
}

function Run-Step([string]$Path, [string[]]$Arguments = @()) {
    & powershell.exe -NoProfile -ExecutionPolicy Bypass -File $Path @Arguments
    if ($LASTEXITCODE -ne 0) { throw "安裝步驟失敗：$Path（結束碼 $LASTEXITCODE）" }
}

try {
    foreach ($relative in @('package.json','ocr\requirements.txt','local-app\prepare-ocr-env.ps1','local-app\install-host-service.ps1')) {
        if (-not (Test-Path -LiteralPath (Join-Path $Source $relative))) { throw "安裝包缺少 $relative。請用 -Source 指定解壓縮後的「詳解應用」資料夾。" }
    }
    Refresh-Path
    if (-not (Get-Command node -ErrorAction SilentlyContinue)) { Install-Package 'OpenJS.NodeJS.LTS' }
    $pythonReady = $false
    try {
        & py -3.11 -c 'import sys; assert sys.version_info[:2] == (3,11)' 2>$null
        $pythonReady = $LASTEXITCODE -eq 0
    } catch {}
    if (-not $pythonReady) { Install-Package 'Python.Python.3.11' }
    & py -3.11 -c 'import sys; assert sys.version_info[:2] == (3,11)'
    if ($LASTEXITCODE -ne 0) { throw 'Python 3.11 尚無法執行，請重新開啟安裝程式。' }
    $tailscale = Join-Path $env:ProgramFiles 'Tailscale\tailscale.exe'
    if (-not (Test-Path -LiteralPath $tailscale)) { Install-Package 'Tailscale.Tailscale' }
    if (-not (Get-Command pdftotext -ErrorAction SilentlyContinue)) { Install-Package 'oschwartz10612.Poppler' }
    if (-not (Get-Command pdftotext -ErrorAction SilentlyContinue)) { throw 'Poppler 安裝後尚未出現在 PATH，請重新開啟安裝程式。' }
    # 每次建立獨立安裝目錄，保留既有主機程式、設定與日誌。
    $target = Join-Path $env:LOCALAPPDATA ('ZiziHost\install-' + [guid]::NewGuid().ToString('N'))
    New-Item -ItemType Directory -Path $target -Force | Out-Null
    Get-ChildItem -LiteralPath $Source -Force | Copy-Item -Destination $target -Recurse -Force
    Write-Host "主機安裝位置：$target" -ForegroundColor Cyan
    Run-Step (Join-Path $target 'local-app\prepare-ocr-env.ps1')
    Push-Location $target
    try {
        & npm.cmd install --omit=dev
        if ($LASTEXITCODE -ne 0) { throw 'Node.js 套件安裝失敗，請查看上方錯誤。' }
    } finally { Pop-Location }
    Run-Step (Join-Path $target 'local-app\install-host-service.ps1') @('-DisplayName', $env:COMPUTERNAME)
    $health = Invoke-RestMethod -Uri 'http://127.0.0.1:8787/api/health' -TimeoutSec 10
    if ($health.service -ne 'tzutzu-ocr') { throw '背景服務安裝後，OCR 健康檢查未通過。' }
    Write-Host 'OCR 主機已安裝並通過連線檢查。請確認 Tailscale 已登入；AI 分類需要此電腦的 AI 工具已登入。' -ForegroundColor Green
    Write-Host "主機在網站上顯示為：$env:COMPUTERNAME"
    exit 0
} catch {
    Write-Host ('安裝未完成：' + $_.Exception.Message) -ForegroundColor Red
    exit 1
}
